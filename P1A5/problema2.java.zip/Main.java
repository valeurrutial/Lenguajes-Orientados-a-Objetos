public class Main {

    public static void main(String[] args) {

        Empleado empleado1 = new Empleado(
                "Juan",
                "Pérez",
                15000.0
        );

        Empleado empleado2 = new Empleado(
                "María",
                "González",
                20000.0
        );

        // Mostrar salarios anuales antes del aumento
        System.out.println("=== SALARIOS ANTES DEL AUMENTO ===");

        System.out.println(
                empleado1.nombre + " " + empleado1.apellido +
                ": $" + empleado1.obtenerSalarioAnual()
        );

        System.out.println(
                empleado2.nombre + " " + empleado2.apellido +
                ": $" + empleado2.obtenerSalarioAnual()
        );


        // Aumento del 10%
        empleado1.aumentarSalario();
        empleado2.aumentarSalario();


        // Mostrar salarios anuales después del aumento
        System.out.println("\n=== SALARIOS DESPUÉS DEL AUMENTO DEL 10% ===");

        System.out.println(
                empleado1.nombre + " " + empleado1.apellido +
                ": $" + empleado1.obtenerSalarioAnual()
        );

        System.out.println(
                empleado2.nombre + " " + empleado2.apellido +
                ": $" + empleado2.obtenerSalarioAnual()
        );
    }
}


class Empleado {

    public String nombre;
    public String apellido;
    public double salarioMensual;


    public Empleado(String nombre, String apellido, double salarioMensual) {

        this.nombre = nombre;
        this.apellido = apellido;

        if (salarioMensual > 0) {
            this.salarioMensual = salarioMensual;
        } else {
            this.salarioMensual = 0.0;
        }
    }


    public double obtenerSalarioAnual() {
        return salarioMensual * 12;
    }


    public void aumentarSalario() {
        salarioMensual = salarioMensual * 1.10;
    }
}