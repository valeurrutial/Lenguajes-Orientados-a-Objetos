public class Main {

    public static void main(String[] args) {

        Factura factura1 = new Factura(
                "A123",
                "Martillo",
                5,
                150.50
        );

        System.out.println("=== FACTURA ===");
        System.out.println("Número de pieza: " + factura1.numeroPieza);
        System.out.println("Descripción: " + factura1.descripcionPieza);
        System.out.println("Cantidad: " + factura1.cantidad);
        System.out.println("Precio por artículo: $" + factura1.precioArticulo);
        System.out.println("Monto total: $" + factura1.obtenerMontoFactura());


        System.out.println("\n=== PRUEBA CON VALORES NEGATIVOS ===");

        Factura factura2 = new Factura(
                "B456",
                "Destornillador",
                -3,
                -50.0
        );

        System.out.println("Cantidad: " + factura2.cantidad);
        System.out.println("Precio: $" + factura2.precioArticulo);
        System.out.println("Monto total: $" + factura2.obtenerMontoFactura());
    }
}


class Factura {

    public String numeroPieza;
    public String descripcionPieza;
    public int cantidad;
    public double precioArticulo;

    public Factura(String numeroPieza, String descripcionPieza,
                   int cantidad, double precioArticulo) {

        this.numeroPieza = numeroPieza;
        this.descripcionPieza = descripcionPieza;

        if (cantidad > 0) {
            this.cantidad = cantidad;
        } else {
            this.cantidad = 0;
        }

        if (precioArticulo > 0) {
            this.precioArticulo = precioArticulo;
        } else {
            this.precioArticulo = 0.0;
        }
    }

    public double obtenerMontoFactura() {
        return cantidad * precioArticulo;
    }
}