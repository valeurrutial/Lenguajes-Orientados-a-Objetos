using System;

public class Main
{
    public static void Main(string[] args)
    {
        Factura factura1 = new Factura(
            "A123",
            "Martillo",
            5,
            150.50
        );

        Console.WriteLine("=== FACTURA ===");
        Console.WriteLine("Número de pieza: " + factura1.numeroPieza);
        Console.WriteLine("Descripción: " + factura1.descripcionPieza);
        Console.WriteLine("Cantidad: " + factura1.cantidad);
        Console.WriteLine("Precio por artículo: $" + factura1.precioArticulo);
        Console.WriteLine("Monto total: $" + factura1.ObtenerMontoFactura());


        Console.WriteLine("\n=== PRUEBA CON VALORES NEGATIVOS ===");

        Factura factura2 = new Factura(
            "B456",
            "Destornillador",
            -3,
            -50.0
        );

        Console.WriteLine("Cantidad: " + factura2.cantidad);
        Console.WriteLine("Precio: $" + factura2.precioArticulo);
        Console.WriteLine("Monto total: $" + factura2.ObtenerMontoFactura());
    }
}


public class Factura
{
    public string numeroPieza;
    public string descripcionPieza;
    public int cantidad;
    public double precioArticulo;

    public Factura(string numeroPieza, string descripcionPieza,
                   int cantidad, double precioArticulo)
    {
        this.numeroPieza = numeroPieza;
        this.descripcionPieza = descripcionPieza;

        if (cantidad > 0)
        {
            this.cantidad = cantidad;
        }
        else
        {
            this.cantidad = 0;
        }

        if (precioArticulo > 0)
        {
            this.precioArticulo = precioArticulo;
        }
        else
        {
            this.precioArticulo = 0.0;
        }
    }

    public double ObtenerMontoFactura()
    {
        return cantidad * precioArticulo;
    }
}