class Fecha:

    # Constructor
    def __init__(self, mes, dia, anio):

        self.mes = mes
        self.dia = dia
        self.anio = anio


    # Método para mostrar la fecha
    def mostrarFecha(self):

        print(
            str(self.mes) + "/" +
            str(self.dia) + "/" +
            str(self.anio)
        )


# Crear un objeto Fecha

fecha1 = Fecha(30, 8, 2026)

print("La fecha es:")

fecha1.mostrarFecha()