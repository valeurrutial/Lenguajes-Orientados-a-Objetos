#include <iostream>

using namespace std;


class Fecha {

public:

    int mes;
    int dia;
    int anio;


    // Constructor
    Fecha(int mes, int dia, int anio) {

        this->mes = mes;
        this->dia = dia;
        this->anio = anio;
    }


    // Método para mostrar la fecha
    void mostrarFecha() {

        cout << mes << "/" << dia << "/" << anio << endl;
    }
};


int main() {

    // Crear un objeto Fecha
    Fecha fecha1(30, 8, 2026);

    cout << "La fecha es:" << endl;

    fecha1.mostrarFecha();

    return 0;
}