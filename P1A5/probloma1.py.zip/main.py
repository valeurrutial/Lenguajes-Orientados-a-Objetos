class Factura:

    def __init__(self, numeroPieza, descripcionPieza,
                 cantidad, precioArticulo):

        self.numeroPieza = numeroPieza
        self.descripcionPieza = descripcionPieza

        if cantidad > 0:
            self.cantidad = cantidad
        else:
            self.cantidad = 0

        if precioArticulo > 0:
            self.precioArticulo = precioArticulo
        else:
            self.precioArticulo = 0.0

    def obtenerMontoFactura(self):
        return self.cantidad * self.precioArticulo


# Programa principal

factura1 = Factura(
    "A123",
    "Martillo",
    5,
    150.50
)

print("=== FACTURA ===")
print("Número de pieza:", factura1.numeroPieza)
print("Descripción:", factura1.descripcionPieza)
print("Cantidad:", factura1.cantidad)
print("Precio por artículo: $", factura1.precioArticulo)
print("Monto total: $", factura1.obtenerMontoFactura())


print("\n=== PRUEBA CON VALORES NEGATIVOS ===")

factura2 = Factura(
    "B456",
    "Destornillador",
    -3,
    -50.0
)

print("Cantidad:", factura2.cantidad)
print("Precio: $", factura2.precioArticulo)
print("Monto total: $", factura2.obtenerMontoFactura())