using System;

public class Main
{
    public static void Main(string[] args)
    {
        // Crear un objeto Fecha
        Fecha fecha1 = new Fecha(30, 8, 2026);

        Console.WriteLine("La fecha es:");

        fecha1.MostrarFecha();
    }
}


public class Fecha
{
    public int mes;
    public int dia;
    public int anio;


    // Constructor
    public Fecha(int mes, int dia, int anio)
    {
        this.mes = mes;
        this.dia = dia;
        this.anio = anio;
    }


    // Método para mostrar la fecha
    public void MostrarFecha()
    {
        Console.WriteLine(mes + "/" + dia + "/" + anio);
    }
}