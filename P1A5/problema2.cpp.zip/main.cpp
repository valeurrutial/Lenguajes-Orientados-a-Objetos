#include <iostream>
#include <string>

using namespace std;


class Empleado {

public:

    string nombre;
    string apellido;
    double salarioMensual;


    Empleado(string nombre, string apellido, double salarioMensual) {

        this->nombre = nombre;
        this->apellido = apellido;

        if (salarioMensual > 0) {
            this->salarioMensual = salarioMensual;
        }
        else {
            this->salarioMensual = 0.0;
        }
    }


    double obtenerSalarioAnual() {
        return salarioMensual * 12;
    }


    void aumentarSalario() {
        salarioMensual = salarioMensual * 1.10;
    }
};


int main() {

    Empleado empleado1(
        "Juan",
        "Perez",
        15000.0
    );

    Empleado empleado2(
        "Maria",
        "Gonzalez",
        20000.0
    );


    // Salarios antes del aumento
    cout << "=== SALARIOS ANTES DEL AUMENTO ===" << endl;

    cout << empleado1.nombre << " "
         << empleado1.apellido
         << ": $" << empleado1.obtenerSalarioAnual()
         << endl;

    cout << empleado2.nombre << " "
         << empleado2.apellido
         << ": $" << empleado2.obtenerSalarioAnual()
         << endl;


    // Aumento del 10%
    empleado1.aumentarSalario();
    empleado2.aumentarSalario();


    // Salarios después del aumento
    cout << "\n=== SALARIOS DESPUES DEL AUMENTO DEL 10% ===" << endl;

    cout << empleado1.nombre << " "
         << empleado1.apellido
         << ": $" << empleado1.obtenerSalarioAnual()
         << endl;

    cout << empleado2.nombre << " "
         << empleado2.apellido
         << ": $" << empleado2.obtenerSalarioAnual()
         << endl;


    return 0;
}