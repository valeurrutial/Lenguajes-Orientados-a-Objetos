#include <iostream>
#include <string>

using namespace std;

class Factura {
public:
    string numeroPieza;
    string descripcionPieza;
    int cantidad;
    double precioArticulo;

    Factura(string numeroPieza, string descripcionPieza,
            int cantidad, double precioArticulo) {

        this->numeroPieza = numeroPieza;
        this->descripcionPieza = descripcionPieza;

        if (cantidad > 0) {
            this->cantidad = cantidad;
        }
        else {
            this->cantidad = 0;
        }

        if (precioArticulo > 0) {
            this->precioArticulo = precioArticulo;
        }
        else {
            this->precioArticulo = 0.0;
        }
    }

    double obtenerMontoFactura() {
        return cantidad * precioArticulo;
    }
};


int main() {

    Factura factura1(
        "A123",
        "Martillo",
        5,
        150.50
    );

    cout << "=== FACTURA ===" << endl;
    cout << "Número de pieza: " << factura1.numeroPieza << endl;
    cout << "Descripción: " << factura1.descripcionPieza << endl;
    cout << "Cantidad: " << factura1.cantidad << endl;
    cout << "Precio por artículo: $" << factura1.precioArticulo << endl;
    cout << "Monto total: $" << factura1.obtenerMontoFactura() << endl;


    cout << "\n=== PRUEBA CON VALORES NEGATIVOS ===" << endl;

    Factura factura2(
        "B456",
        "Destornillador",
        -3,
        -50.0
    );

    cout << "Cantidad: " << factura2.cantidad << endl;
    cout << "Precio: $" << factura2.precioArticulo << endl;
    cout << "Monto total: $" << factura2.obtenerMontoFactura() << endl;

    return 0;
}