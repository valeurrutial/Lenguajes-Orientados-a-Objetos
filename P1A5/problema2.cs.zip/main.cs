using System;

public class Main
{
    public static void Main(string[] args)
    {
        Empleado empleado1 = new Empleado(
            "Juan",
            "Pérez",
            15000.0
        );

        Empleado empleado2 = new Empleado(
            "María",
            "González",
            20000.0
        );


        // Salarios antes del aumento
        Console.WriteLine("=== SALARIOS ANTES DEL AUMENTO ===");

        Console.WriteLine(
            empleado1.nombre + " " + empleado1.apellido +
            ": $" + empleado1.ObtenerSalarioAnual()
        );

        Console.WriteLine(
            empleado2.nombre + " " + empleado2.apellido +
            ": $" + empleado2.ObtenerSalarioAnual()
        );


        // Aumento del 10%
        empleado1.AumentarSalario();
        empleado2.AumentarSalario();


        // Salarios después del aumento
        Console.WriteLine("\n=== SALARIOS DESPUÉS DEL AUMENTO DEL 10% ===");

        Console.WriteLine(
            empleado1.nombre + " " + empleado1.apellido +
            ": $" + empleado1.ObtenerSalarioAnual()
        );

        Console.WriteLine(
            empleado2.nombre + " " + empleado2.apellido +
            ": $" + empleado2.ObtenerSalarioAnual()
        );
    }
}


public class Empleado
{
    public string nombre;
    public string apellido;
    public double salarioMensual;


    public Empleado(string nombre, string apellido, double salarioMensual)
    {
        this.nombre = nombre;
        this.apellido = apellido;

        if (salarioMensual > 0)
        {
            this.salarioMensual = salarioMensual;
        }
        else
        {
            this.salarioMensual = 0.0;
        }
    }


    public double ObtenerSalarioAnual()
    {
        return salarioMensual * 12;
    }


    public void AumentarSalario()
    {
        salarioMensual = salarioMensual * 1.10;
    }
}