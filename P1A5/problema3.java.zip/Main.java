public class Main {

    public static void main(String[] args) {

        // Crear un objeto Fecha
        Fecha fecha1 = new Fecha(30, 8, 2026);

        System.out.println("La fecha es:");

        fecha1.mostrarFecha();
    }
}


class Fecha {

    public int mes;
    public int dia;
    public int anio;


    // Constructor
    public Fecha(int mes, int dia, int anio) {

        this.mes = mes;
        this.dia = dia;
        this.anio = anio;
    }


    // Método para mostrar la fecha
    public void mostrarFecha() {

        System.out.println(mes + "/" + dia + "/" + anio);
    }
}