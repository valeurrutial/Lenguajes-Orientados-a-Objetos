class Empleado:

    def __init__(self, nombre, apellido, salarioMensual):

        self.nombre = nombre
        self.apellido = apellido

        if salarioMensual > 0:
            self.salarioMensual = salarioMensual
        else:
            self.salarioMensual = 0.0


    def obtenerSalarioAnual(self):
        return self.salarioMensual * 12


    def aumentarSalario(self):
        self.salarioMensual = self.salarioMensual * 1.10


# Crear los empleados

empleado1 = Empleado(
    "Juan",
    "Pérez",
    15000.0
)

empleado2 = Empleado(
    "María",
    "González",
    20000.0
)


# Mostrar salarios antes del aumento

print("=== SALARIOS ANTES DEL AUMENTO ===")

print(
    empleado1.nombre,
    empleado1.apellido,
    ": $",
    empleado1.obtenerSalarioAnual()
)

print(
    empleado2.nombre,
    empleado2.apellido,
    ": $",
    empleado2.obtenerSalarioAnual()
)


# Dar aumento del 10%

empleado1.aumentarSalario()
empleado2.aumentarSalario()


# Mostrar salarios después del aumento

print("\n=== SALARIOS DESPUÉS DEL AUMENTO DEL 10% ===")

print(
    empleado1.nombre,
    empleado1.apellido,
    ": $",
    empleado1.obtenerSalarioAnual()
)

print(
    empleado2.nombre,
    empleado2.apellido,
    ": $",
    empleado2.obtenerSalarioAnual()
)